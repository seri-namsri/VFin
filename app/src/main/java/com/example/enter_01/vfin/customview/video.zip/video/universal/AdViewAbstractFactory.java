package com.example.enter_01.vfin.customview.video.universal;

import android.content.Context;
import android.view.View;

import com.example.enter_01.vfin.customview.video.universal.internal.AdInteractiveMediaOperationImpHandler;
import com.example.enter_01.vfin.customview.video.universal.internal.AdVideoNativeMp4OperationImplHandler;
import com.example.enter_01.vfin.customview.video.universal.internal.AdVideoYoutubeApiOperationImplHandler;
import com.example.enter_01.vfin.customview.video.universal.internal.AdVideoYoutubeWebViewOperationImplHandler;
import com.example.enter_01.vfin.customview.video.universal.internal.AdWebViewOperationImplHandler;
import com.example.enter_01.vfin.customview.video.videonative.Settings;
import com.google.android.youtube.player.YouTubeApiServiceUtil;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubeIntents;


/**
 * Created by nickmsft on 11/15/2015 AD.
 * .
 */
public class AdViewAbstractFactory {
    private static AdViewAbstractFactory instance;
    private Context context;
    private View.OnTouchListener onTouchListener;
    private DataSource dataSource;
    private View adViewUniversalLayout;

    public static AdViewAbstractFactory createAdViewFactory(Context context) {
//        if (instance == null){
//            instance = new AdViewAbstractFactory(context);
//        }
        instance = new AdViewAbstractFactory(context);
        instance.dataSource = null;
        instance.onTouchListener = null;
        return instance;
    }

    private AdViewAbstractFactory(Context context) {
        this.context = context;
    }

    public AdViewAbstractFactory setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
        return this;
    }

    public AdViewAbstractFactory setOnTouchListener(View.OnTouchListener onTouchListener) {
        this.onTouchListener = onTouchListener;
        return this;
    }

    public AdViewAbstractFactory setAdViewUniversalLayout(View adViewUniversalLayout) {
        this.adViewUniversalLayout = adViewUniversalLayout;
        return this;
    }

    public IAdViewOperationHandler createAdViewOperation() {
        if ((dataSource != null) && (adViewUniversalLayout != null))
        {
            if (dataSource.getFormatType().equalsIgnoreCase("mp4") ||
                    dataSource.getFormatType().equalsIgnoreCase("local"))
            {
                Settings settings = new Settings(context);

                if (dataSource.getFormatType().equalsIgnoreCase("local"))
                {
                    settings.setPlayer(Settings.PV_PLAYER__AndroidMediaPlayer);
                } else {
                    settings.setPlayer(Settings.PV_PLAYER__IjkMediaPlayer);
                }
                AdVideoNativeMp4OperationImplHandler adVideoNativeMp4OperationImplHandler =
                        new AdVideoNativeMp4OperationImplHandler(context, adViewUniversalLayout, dataSource);
                if (onTouchListener != null) {
                    adVideoNativeMp4OperationImplHandler.setOnTouchListener(onTouchListener);
                }
                return adVideoNativeMp4OperationImplHandler;
            } else if (dataSource.getFormatType().equalsIgnoreCase("youtube")) {
                // check youtube has installed
                if(YouTubeIntents.isYouTubeInstalled(context) &&
                        (YouTubeApiServiceUtil.isYouTubeApiServiceAvailable(context) == YouTubeInitializationResult.SUCCESS)) {

                    AdVideoYoutubeApiOperationImplHandler adVideoYoutubeApiOperationImplHandler =
                            new AdVideoYoutubeApiOperationImplHandler(context, adViewUniversalLayout,dataSource);
                    if(onTouchListener != null) {
                        adVideoYoutubeApiOperationImplHandler.setOnTouchListener(onTouchListener);
                    }
                    return  adVideoYoutubeApiOperationImplHandler;

                } else {
                    AdVideoYoutubeWebViewOperationImplHandler adVideoYoutubeWebViewOperationImplHandler =
                            new AdVideoYoutubeWebViewOperationImplHandler(context, adViewUniversalLayout, dataSource);
                    if (onTouchListener != null) {
                        adVideoYoutubeWebViewOperationImplHandler.setOnTouchListener(onTouchListener);
                    }
                    return adVideoYoutubeWebViewOperationImplHandler;
                }
            } else if (dataSource.getFormatType().equalsIgnoreCase("vast2")) {
                AdInteractiveMediaOperationImpHandler adInteractiveMediaOperationImpHandler =
                        new AdInteractiveMediaOperationImpHandler(context, adViewUniversalLayout, dataSource);
                if (onTouchListener != null) {
                    adInteractiveMediaOperationImpHandler.setOnTouchListener(onTouchListener);
                }
                return adInteractiveMediaOperationImpHandler;
            } else if (dataSource.getFormatType().equalsIgnoreCase("banner")) {
                AdWebViewOperationImplHandler adWebViewOperationImplHandler =
                        new AdWebViewOperationImplHandler(context, adViewUniversalLayout, dataSource);
                if (onTouchListener != null) {
                    adWebViewOperationImplHandler.setOnTouchListener(onTouchListener);
                }
                return adWebViewOperationImplHandler;
            }

        }
        return null;
    }
}
