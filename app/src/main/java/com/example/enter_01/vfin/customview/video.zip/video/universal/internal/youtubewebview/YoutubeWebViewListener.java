package com.example.enter_01.vfin.customview.video.universal.internal.youtubewebview;

/**
 * Created by iceoton on 6/13/2016 AD.
 */
public interface YoutubeWebViewListener {

    void onUpdateVideoTime(double time);
    void onLoading();
    void onReady();
    void onPlay();
    void onPlaying();
    void onVideoEnded();
    void onError(String errorReason);
}
