package com.example.enter_01.vfin.customview.video.universal;

/**
 * Created by nickmsft on 11/15/2015 AD.
 * .log.
 */
public interface IDooAdCallBack {
    void onPrepare(IDooAdMediaPlayer iDooAdMediaPlayer);

    void onLoadAdComplete();

    void onPlay();

    void onPlaying();

    void onComplete(IDooAdMediaPlayer iDooAdMediaPlayer,
                    DataSource dataSource,
                    boolean dooAdComplete,
                    long timeStamp);

    void onError(IDooAdMediaPlayer iDooAdMediaPlayer, DataSource dataSource, int errorId1, int error2, String error);
}
