package com.example.enter_01.vfin.customview.video.universal;

/**
 * Created by nickmsft on 11/25/2015 AD.
 * .log.
 */
public interface IDooAdMediaPlayer {
    void setVolume(float var1, float var2);
    boolean isPlaying();
}
