package com.example.enter_01.vfin.customview.video.universal.internal;


import com.example.enter_01.vfin.customview.video.universal.IDooAdMediaPlayer;

/**
 * Created by nickmsft on 12/8/2015 AD.
 * .
 */
public class AdInteractiveMediaPlayer implements IDooAdMediaPlayer {
    @Override
    public void setVolume(float var1, float var2) {

    }

    @Override
    public boolean isPlaying() {
        return false;
    }
}
