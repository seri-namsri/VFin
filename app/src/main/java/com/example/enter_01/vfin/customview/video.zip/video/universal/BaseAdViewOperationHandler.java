package com.example.enter_01.vfin.customview.video.universal;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

import com.example.enter_01.vfin.R;


/**
 * Created by nickmsft on 11/15/2015 AD.
 * .
 */
public abstract class BaseAdViewOperationHandler {
    private View view;
    private Context context;
    private DataSource dataSource;

    private View.OnTouchListener touchListener;
    public BaseAdViewOperationHandler(Context context,View view,DataSource dataSource){
        this.context = context;
        this.view = view;
        this.dataSource = dataSource;
    }

    public BaseAdViewOperationHandler(Context context,View view){
        this.context = context;
        this.view = view;
    }

    public void setTouchListener(View.OnTouchListener touchListener) {
        this.touchListener = touchListener;
    }
    protected View.OnTouchListener getTouchListener()
    {
        return this.touchListener;
    }

    protected void addAdPlayerToContainer(View viewAdPlayer){
        ViewGroup viewGroup = (ViewGroup)this.view.findViewById(R.id.ads_view_container);
        viewGroup.addView(viewAdPlayer);
    }
    public View getView() {
        return view;
    }

    public void setView(View view) {
        this.view = view;
    }

    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }

    public DataSource getDataSource() {
        return dataSource;
    }

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }
}
