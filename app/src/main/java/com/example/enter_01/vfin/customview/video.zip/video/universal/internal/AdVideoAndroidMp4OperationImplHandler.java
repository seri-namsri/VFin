package com.example.enter_01.vfin.customview.video.universal.internal;

import android.content.Context;
import android.media.MediaPlayer;
import android.net.Uri;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.MediaController;
import android.widget.VideoView;

import com.example.enter_01.vfin.R;
import com.example.enter_01.vfin.customview.CustomMediaController;
import com.example.enter_01.vfin.customview.video.universal.BaseAdViewOperationHandler;
import com.example.enter_01.vfin.customview.video.universal.DataSource;
import com.example.enter_01.vfin.customview.video.universal.IAdViewOperationHandler;
import com.example.enter_01.vfin.customview.video.universal.IDooAdCallBack;


/**
 * Created by nickmsft on 11/26/2015 AD.
 * .
 */
public class AdVideoAndroidMp4OperationImplHandler
        extends BaseAdViewOperationHandler
        implements IAdViewOperationHandler {

    private VideoView videoView;
    private MediaPlayer mediaPlayer;
    private View.OnTouchListener onTouchListener;
    private MediaController mediaController;

    public AdVideoAndroidMp4OperationImplHandler(Context context,
                                                 View view,
                                                 DataSource dataSource) {
        super(context, view, dataSource);
    }

    public AdVideoAndroidMp4OperationImplHandler(Context context, View view) {
        super(context, view);
    }


    @Override
    public void initial(boolean mute, Fragment container, final IDooAdCallBack dooAdListener) {
        LayoutInflater layoutInflater = LayoutInflater.from(getContext());
        View view = layoutInflater.inflate(R.layout.universal_mp4_android_video_layout, null);
        addAdPlayerToContainer(view);

        videoView = (VideoView) view.findViewById(R.id.doo_ads_android_view);


        mediaController = new CustomMediaController(getContext());
        mediaController.setAnchorView(videoView);
        mediaController.setMediaPlayer(videoView);

        Uri url = Uri.parse(getDataSource().getUrl());

        videoView.setMediaController(mediaController);
        videoView.setVideoURI(url);

        videoView.requestFocus();

        if (onTouchListener != null) {
            videoView.setOnTouchListener(this.onTouchListener);
        }

        videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                mediaPlayer = mp;
                dooAdListener.onPrepare(new AdVideoAndroidMp4MediaPlayer(mp));
            }
        });

        videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                boolean isCompleteOrNot = (mp.getCurrentPosition() >= mp.getDuration());

                dooAdListener.onComplete(new AdVideoAndroidMp4MediaPlayer(mp),
                        getDataSource(),
                        isCompleteOrNot, mp.getCurrentPosition());

            }
        });

        videoView.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            @Override
            public boolean onError(MediaPlayer mp, int what, int extra) {
                dooAdListener.onError(new AdVideoAndroidMp4MediaPlayer(mp),
                        getDataSource(),
                        what,
                        extra,
                        "");

                return true;
            }
        });
    }

    @Override
    public void startAd() {
        if (videoView != null) {
            videoView.start();
        }
    }

    @Override
    public void stopAd() {
        if (videoView != null) {
            videoView.stopPlayback();
            if (mediaPlayer != null) {
                mediaPlayer.release();
            }
            mediaPlayer = null;
            videoView = null;
        }
    }

    @Override
    public void pause() {
        if (videoView != null) {
            videoView.pause();
        }
    }

    @Override
    public void resume() {
        if (videoView != null) {
            videoView.resume();
        }
    }

    @Override
    public long getDuration() {
        if (videoView != null) {
            return videoView.getDuration();
        }
        return 0;
    }

    @Override
    public boolean isPlaying() {
        if (videoView != null) {
            return videoView.isPlaying();
        }
        return false;
    }

    @Override
    public long getCurrentPosition() {
        if (videoView != null) {
            return videoView.getCurrentPosition();
        }
        return 0;
    }

    @Override
    public View getInternalAdView() {
        return videoView;
    }

    @Override
    public void setOnTouchListener(View.OnTouchListener touchListener) {
        this.onTouchListener = touchListener;
    }

    @Override
    public void uninitial() {

    }
}
