package com.example.enter_01.vfin.customview.video.universal.internal;


import android.content.Context;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.enter_01.vfin.R;
import com.example.enter_01.vfin.customview.video.interactivemedia.VideoPlayer;
import com.example.enter_01.vfin.customview.video.interactivemedia.VideoPlayerController;
import com.example.enter_01.vfin.customview.video.universal.BaseAdViewOperationHandler;
import com.example.enter_01.vfin.customview.video.universal.DataSource;
import com.example.enter_01.vfin.customview.video.universal.IAdViewOperationHandler;
import com.example.enter_01.vfin.customview.video.universal.IDooAdCallBack;


/**
 * Created by nickmsft on 11/25/2015 AD.
 * .
 */
public class AdInteractiveMediaOperationImpHandler extends BaseAdViewOperationHandler
        implements IAdViewOperationHandler {

    private final static String TAG = AdInteractiveMediaOperationImpHandler.class.getSimpleName();


    // The video player.
    private static VideoPlayer mVideoPlayer;
    // The container for the ad's UI.
    private static ViewGroup mAdUIContainer;
    // The play button to trigger the ad request.


    private View.OnTouchListener onTouchListener;

    protected VideoPlayerController mVideoPlayerController;

    public AdInteractiveMediaOperationImpHandler(Context context,
                                                 View view,
                                                 DataSource dataSource) {
        super(context, view, dataSource);
    }





    @Override
    public View getInternalAdView() {
        return null;
    }

    @Override
    public void initial(boolean mute,
                        Fragment container,
                        IDooAdCallBack dooAdListener) {

        LayoutInflater layoutInflater = LayoutInflater.from(getContext());
        View view = layoutInflater.inflate(R.layout.universal_ima_view_layout, null);
        addAdPlayerToContainer(view);

        mVideoPlayer = (VideoPlayer) view.findViewById(R.id.video_ad_player);
        mAdUIContainer = (ViewGroup) view.findViewById(R.id.videoPlayerWithAdPlayback);

        mVideoPlayerController = new VideoPlayerController(getContext(),
                mVideoPlayer,
                mAdUIContainer,
                getDataSource().getUrl(),
                getDataSource(),
                dooAdListener);

        if (onTouchListener != null){
            if (mAdUIContainer != null)
                mAdUIContainer.setOnTouchListener(onTouchListener);
        }

        if (dooAdListener != null)
        {
            dooAdListener.onPrepare(new AdInteractiveMediaPlayer());
        }

        //startAd();

        //mVideoPlayerController.setContentVideo(getDataSource().getUrl());

        //mVideoPlayerController.setContentVideo(getContext().getString(R.string.content_url));
    }

    @Override
    public void startAd() {
        if (mVideoPlayerController != null){
            if (!mVideoPlayerController.isPlaying()) {
                mVideoPlayerController.play();
            }
        }
    }

    @Override
    public void stopAd() {
        if (mVideoPlayerController != null){
            mVideoPlayerController.stop();
        }
        mVideoPlayerController = null;
    }

    @Override
    public void pause() {
        if (mVideoPlayerController != null){
            mVideoPlayerController.pause();
        }
    }

    @Override
    public void resume() {
        if (mVideoPlayerController != null){
            mVideoPlayerController.resume();
        }
    }

    @Override
    public void setOnTouchListener(View.OnTouchListener touchListener) {
        this.onTouchListener = touchListener;
    }

    @Override
    public long getDuration() {
        if (mVideoPlayerController != null){
            long duration =  mVideoPlayerController.getAdDuration();
          //  UtilsLog.info(TAG,"get duration = "+duration);
            if (duration > 0)
                return duration;
        }
        return 0;
    }

    @Override
    public boolean isPlaying() {
        boolean isPlaying = false;
        if (mVideoPlayerController != null) {
            isPlaying =  mVideoPlayerController.isPlaying();
        }
        return isPlaying;
    }

    @Override
    public long getCurrentPosition() {
        if (mVideoPlayerController != null){
            long currentPosition =  mVideoPlayerController.getAdCurrentPosition();
         //   UtilsLog.info(TAG,"get current position = "+currentPosition);
            if (currentPosition > 0)
                return currentPosition;
        }
        return 0;
    }

    @Override
    public void uninitial() {

    }
}
