package com.example.enter_01.vfin.customview.video.universal.internal;

import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;

import com.example.enter_01.vfin.R;
import com.example.enter_01.vfin.customview.video.universal.BaseAdViewOperationHandler;
import com.example.enter_01.vfin.customview.video.universal.DataSource;
import com.example.enter_01.vfin.customview.video.universal.IAdViewOperationHandler;
import com.example.enter_01.vfin.customview.video.universal.IDooAdCallBack;
import com.example.enter_01.vfin.customview.video.videonative.DooAdsVideoView;
import com.example.enter_01.vfin.customview.video.videonative.Settings;

import tv.danmaku.ijk.media.player.IMediaPlayer;


/**
 * Created by nickmsft on 11/15/2015 AD.
 * .
 */
public class AdVideoNativeMp4OperationImplHandler extends BaseAdViewOperationHandler implements IAdViewOperationHandler {

    private final static String TAG = AdVideoNativeMp4OperationImplHandler.class.getSimpleName();


    private DooAdsVideoView dooAdsVideoView;
    private View.OnTouchListener onTouchListener;
    private IDooAdCallBack dooAdListener;

    public AdVideoNativeMp4OperationImplHandler(Context context,
                                                View view,
                                                DataSource dataSource) {
        super(context, view, dataSource);
    }


    @Override
    public void initial(final boolean mute,
                        Fragment holder,
                        final IDooAdCallBack dooAdListener) {


        /*
        try {

            IjkMediaPlayer.loadLibrariesOnce(new IjkLibLoader() {
                @Override
                public void loadLibrary(String libName) throws UnsatisfiedLinkError, SecurityException {
                    try{
                        System.loadLibrary(libName);
                    }catch (UnsatisfiedLinkError unsatisfiedLinkError){

                    }catch (SecurityException se){

                    }
                }
            });
            IjkMediaPlayer.native_profileBegin("libijkplayer.so");

        }catch (UnsatisfiedLinkError ex){
            UtilsLog.error(TAG,ex.getMessage());
        }catch (SecurityException se){
            UtilsLog.error(TAG,se.getMessage());
        }catch (Exception ex){
            UtilsLog.error(TAG,ex.getMessage());
        }
*/


        Settings settings = new Settings(getContext());


        LayoutInflater layoutInflater = LayoutInflater.from(getContext());
        View view = layoutInflater.inflate(R.layout.universal_mp4_native_view_layout, null);
        addAdPlayerToContainer(view);
        dooAdsVideoView = (DooAdsVideoView) view.findViewById(R.id.doo_ads_view);

        if (settings.getPlayer() == Settings.PV_PLAYER__IjkMediaPlayer) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                settings.settUsingMediaCodec(true);
            }
            settings.setEnableSurfaceView(true);

        }


        //String fileName = "android.resource://"+  getContext().getPackageName() + "/raw/ais_001_low";

      //  UtilsLog.debug(TAG, "AdVideoNative playing url ->" + getDataSource().getUrl());

        dooAdsVideoView.setVideoURI(Uri.parse(getDataSource().getUrl()));

        //dooAdsVideoView.setVideoURI(Uri.parse(fileName));

        dooAdsVideoView.setOnPreparedListener(new IMediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(IMediaPlayer iMediaPlayer) {
                if (mute) {
                    iMediaPlayer.setVolume(0, 0);
                }
                if (dooAdListener != null) {
                    dooAdListener.onPrepare(
                            new AdVideoNativeMp4MediaPlayer(iMediaPlayer)
                    );
                }
            }
        });
        dooAdsVideoView.setOnCompletionListener(new IMediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(IMediaPlayer iMediaPlayer) {
                try {
                    if (dooAdListener != null) {
                        boolean isCompleteOrNot = (iMediaPlayer.getCurrentPosition() >= iMediaPlayer.getDuration());
                        dooAdListener.onComplete(new AdVideoNativeMp4MediaPlayer(iMediaPlayer),
                                getDataSource(),
                                isCompleteOrNot,
                                iMediaPlayer.getCurrentPosition());
                    }
                } catch (IndexOutOfBoundsException e) {
                  //  UtilsLog.error(TAG, e.getMessage());
                }
            }
        });
        dooAdsVideoView.setOnErrorListener(new IMediaPlayer.OnErrorListener() {
            @Override
            public boolean onError(IMediaPlayer iMediaPlayer, int i, int i1) {
                if (dooAdListener != null) {
                    dooAdListener.onError(new AdVideoNativeMp4MediaPlayer(iMediaPlayer), getDataSource(), i, i1, "");
                }
                return false;
            }
        });

        this.dooAdListener = dooAdListener;
    }

    @Override
    public void startAd() {
        if (dooAdsVideoView != null) {
            if (this.onTouchListener != null) {
                dooAdsVideoView.setOnTouchListener(this.onTouchListener);
            }
            dooAdsVideoView.start();
        }
        if(dooAdListener != null){
            dooAdListener.onPlay();
        }
    }

    @Override
    public void setOnTouchListener(View.OnTouchListener touchListener) {
        this.onTouchListener = touchListener;
    }

    @Override
    public void stopAd() {
        /*
           clear all
        */
        if (dooAdsVideoView != null) {
            if (!dooAdsVideoView.isBackgroundPlayEnabled()) {
                dooAdsVideoView.stopPlayback();
                dooAdsVideoView.release(true);
                dooAdsVideoView.stopBackgroundPlay();
            } else {
                dooAdsVideoView.enterBackground();
            }
        }
        dooAdsVideoView = null;

        /*
        try {
            IjkMediaPlayer.native_profileEnd();
        }catch (UnsatisfiedLinkError unsatisfiedLinkError){
            unsatisfiedLinkError.printStackTrace();
        }catch (SecurityException se){
            se.printStackTrace();
        }catch (Exception ex){ex.printStackTrace();}
*/

    }

    @Override
    public void pause() {
        if (dooAdsVideoView != null) dooAdsVideoView.pause();
    }

    @Override
    public void resume() {
        if (dooAdsVideoView != null) dooAdsVideoView.resume();
    }


    @Override
    public View getInternalAdView() {
        return dooAdsVideoView;
    }


    @Override
    public long getDuration() {
        if (dooAdsVideoView != null) return dooAdsVideoView.getDuration();
        return 0;
    }

    @Override
    public boolean isPlaying() {
        if (dooAdsVideoView != null) return dooAdsVideoView.isPlaying();
        return false;
    }

    @Override
    public long getCurrentPosition() {
        if (dooAdsVideoView != null) return dooAdsVideoView.getCurrentPosition();

        return 0;
    }


    @Override
    public void uninitial() {

    }
}
