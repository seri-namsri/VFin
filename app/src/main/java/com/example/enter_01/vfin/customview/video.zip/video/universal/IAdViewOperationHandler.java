package com.example.enter_01.vfin.customview.video.universal;

import android.support.v4.app.Fragment;
import android.view.View;

/**
 * Created by nickmsft on 11/15/2015 AD.
 * .
 */
public interface IAdViewOperationHandler {
    void initial(
            boolean mute,
            Fragment container,
            IDooAdCallBack dooAdListener
    );
    void startAd();
    void stopAd();
    void pause();
    void resume();
    long getDuration();
    boolean isPlaying();
    long getCurrentPosition();

    void uninitial();

    View getInternalAdView();
    void setOnTouchListener(View.OnTouchListener touchListener);


}
