package com.example.enter_01.vfin.customview.video.universal.internal;

import android.content.Context;
import android.view.View;

import com.example.enter_01.vfin.customview.video.universal.BaseAdViewOperationHandler;
import com.example.enter_01.vfin.customview.video.universal.DataSource;
import com.example.enter_01.vfin.customview.video.universal.IAdViewOperationHandler;
import com.example.enter_01.vfin.customview.video.universal.IDooAdCallBack;

/**
 * Created by nickmsft on 12/6/2015 AD.
 * .
 */
public class AdImageViewOperationImplHandler extends BaseAdViewOperationHandler
        implements IAdViewOperationHandler {

    public AdImageViewOperationImplHandler(Context context, View view, DataSource dataSource) {
        super(context, view, dataSource);
    }

    public AdImageViewOperationImplHandler(Context context, View view) {
        super(context, view);
    }

    @Override
    public void initial(boolean mute, android.support.v4.app.Fragment container, IDooAdCallBack dooAdListener) {

    }

    @Override
    public void startAd() {

    }

    @Override
    public void stopAd() {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public long getDuration() {
        return 0;
    }

    @Override
    public boolean isPlaying() {
        return false;
    }

    @Override
    public long getCurrentPosition() {
        return 0;
    }

    @Override
    public void uninitial() {

    }

    @Override
    public View getInternalAdView() {
        return null;
    }

    @Override
    public void setOnTouchListener(View.OnTouchListener touchListener) {

    }
}
