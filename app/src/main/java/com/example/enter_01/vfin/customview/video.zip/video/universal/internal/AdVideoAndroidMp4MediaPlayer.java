package com.example.enter_01.vfin.customview.video.universal.internal;

import android.media.MediaPlayer;

import com.example.enter_01.vfin.customview.video.universal.IDooAdMediaPlayer;


/**
 * Created by nickmsft on 11/26/2015 AD.
 * .
 */
public class AdVideoAndroidMp4MediaPlayer implements IDooAdMediaPlayer {

    private MediaPlayer mediaPlayer;
    public AdVideoAndroidMp4MediaPlayer(MediaPlayer mediaPlayer){
        this.mediaPlayer = new MediaPlayer();
    }
    @Override
    public void setVolume(float var1, float var2) {
        if (mediaPlayer != null)
        this.mediaPlayer.setVolume(var1,var2);
    }

    @Override
    public boolean isPlaying() {
        if (mediaPlayer != null)
            return this.mediaPlayer.isPlaying();

        return false;
    }
}
