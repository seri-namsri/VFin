package com.example.enter_01.vfin.customview.video.universal.internal;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Build;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.WebView;
import android.widget.ProgressBar;

import com.example.enter_01.vfin.R;
import com.example.enter_01.vfin.customview.video.universal.BaseAdViewOperationHandler;
import com.example.enter_01.vfin.customview.video.universal.DataSource;
import com.example.enter_01.vfin.customview.video.universal.IAdViewOperationHandler;
import com.example.enter_01.vfin.customview.video.universal.IDooAdCallBack;
import com.example.enter_01.vfin.customview.video.universal.internal.youtubewebview.YoutubeWebViewListener;
import com.example.enter_01.vfin.customview.video.universal.internal.youtubewebview.YoutubeWebViewPlayer;


public class AdVideoYoutubeWebViewOperationImplHandler extends BaseAdViewOperationHandler implements
        IAdViewOperationHandler {

    private final static String TAG = AdVideoYoutubeWebViewOperationImplHandler.class.getSimpleName();

    YoutubeWebViewPlayer youtubeWebViewPlayer;
    ProgressBar youtubeProgress;

    IDooAdCallBack dooAdListener;

    public AdVideoYoutubeWebViewOperationImplHandler(Context context,
                                                     View view,
                                                     DataSource dataSource) {
        super(context, view, dataSource);
    }

    @Override
    public void stopAd() {

    }

    @Override
    public void pause() {
        if (youtubeWebViewPlayer != null) {
            youtubeWebViewPlayer.pause();
        }
    }

    @Override
    public void startAd() {
        if (youtubeWebViewPlayer != null) {
            youtubeWebViewPlayer.play();
        }
    }

    @Override
    public void resume() {
    }

    @Override
    public View getInternalAdView() {
        return null;
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void initial(boolean mute, Fragment container, final IDooAdCallBack dooAdListener) {
        LayoutInflater layoutInflater = LayoutInflater.from(getContext());
        View view = layoutInflater.inflate(R.layout.universal_youtube_webview_layout, null);
        addAdPlayerToContainer(view);
        WebView webViewVideo = (WebView) view.findViewById(R.id.webviewVideo);
        youtubeProgress = (ProgressBar) view.findViewById(R.id.progressVideo);

        int currentapiVersion = Build.VERSION.SDK_INT;
        if (currentapiVersion >= Build.VERSION_CODES.LOLLIPOP) {
            // Do something for lollipop and above versions
            youtubeProgress.setProgressTintList(ColorStateList.valueOf(Color.RED));
        } else {
            // do something for phones running an SDK before lollipop
            youtubeProgress.getProgressDrawable().setColorFilter(
                    Color.RED, PorterDuff.Mode.MULTIPLY);
        }


        if (webViewVideo != null) {
            String url = getDataSource().getUrl();
            String videoId = url.split("=")[1];
            youtubeWebViewPlayer = new YoutubeWebViewPlayer(getContext(), webViewVideo);
            youtubeWebViewPlayer.setYoutubeWebViewListener(new YoutubeWebViewListener() {
                @Override
                public void onUpdateVideoTime(double timeSec) {
                    if (youtubeProgress != null) {
                        final int MAX_PROGRESS = 1000;
                        int progress = (int) (timeSec / (getDataSource().getDuration() / 1000) * MAX_PROGRESS);
                        youtubeProgress.setMax(MAX_PROGRESS);
                        youtubeProgress.setProgress(progress);
                    }
                }

                @Override
                public void onLoading() {
                    if (dooAdListener != null) {
                        dooAdListener.onPrepare(null);
                    }
                }

                @Override
                public void onReady() {
                    if (dooAdListener != null) {
                        dooAdListener.onLoadAdComplete();
                    }
                }

                @Override
                public void onPlay() {
                    if (dooAdListener != null) {
                        dooAdListener.onPlay();
                    }
                }

                @Override
                public void onPlaying() {
                    if (dooAdListener != null) {
                        dooAdListener.onPlaying();
                    }
                }

                @Override
                public void onVideoEnded() {
                    if (dooAdListener != null) {
                        dooAdListener.onComplete(null, getDataSource(), true, youtubeWebViewPlayer.getCurrentTimeMillis());
                    }
                }

                @Override
                public void onError(String errorReason) {
                    if (dooAdListener != null) {
                        dooAdListener.onError(null, getDataSource(), 0, 0, errorReason);
                    }
                }
            });
            youtubeWebViewPlayer.load(videoId);
        }

        this.dooAdListener = dooAdListener;
    }

    @Override
    public void setOnTouchListener(View.OnTouchListener touchListener) {
//        this.onTouchListener = touchListener;
    }

    @Override
    public long getDuration() {
        return getDataSource().getDuration();
    }

    @Override
    public boolean isPlaying() {
        return false;
    }

    @Override
    public long getCurrentPosition() {
        if (youtubeWebViewPlayer != null) {
            try {
                return youtubeWebViewPlayer.getCurrentTimeMillis();
            } catch (IllegalStateException e) {
                return 0;
            }
        }
        return 0;
    }

    @Override
    public void uninitial() {
        if (youtubeWebViewPlayer != null) {
            youtubeWebViewPlayer.release();
        }
    }
}
