package com.example.enter_01.vfin.customview.video.universal.internal;

import android.content.Context;
import android.graphics.Bitmap;
import android.support.v4.app.Fragment;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;


import com.example.enter_01.vfin.R;
import com.example.enter_01.vfin.customview.video.universal.BaseAdViewOperationHandler;
import com.example.enter_01.vfin.customview.video.universal.DataSource;
import com.example.enter_01.vfin.customview.video.universal.IAdViewOperationHandler;
import com.example.enter_01.vfin.customview.video.universal.IDooAdCallBack;

import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by nickmsft on 12/6/2015 AD.
 * .
 */
public class AdWebViewOperationImplHandler extends BaseAdViewOperationHandler
        implements IAdViewOperationHandler {

    /*
    */
    private WebView webView;
    private View.OnTouchListener onTouchListener;
    private int count = 0;
    private Timer timer;
    private IDooAdCallBack iDooAdCallBack;
    public AdWebViewOperationImplHandler(Context context,
                                         View view,
                                         DataSource dataSource) {
        super(context, view, dataSource);
    }

    public AdWebViewOperationImplHandler(Context context,
                                         View view) {
        super(context, view);
    }

    @Override
    public void initial(boolean mute,
                        Fragment container,
                        IDooAdCallBack dooAdListener) {
        LayoutInflater layoutInflater = LayoutInflater.from(getContext());
        View view = layoutInflater.inflate(R.layout.universal_banner_layout, null);
        addAdPlayerToContainer(view);
        webView = (WebView)view.findViewById(R.id.web_banner);

        webView.clearCache(true);
        webView.clearHistory();
        webView.setWebViewClient(new CustomWebClient());
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if ((keyCode == KeyEvent.KEYCODE_BACK) && webView.canGoBack()) {
                    return true;
                }
                return false;
            }
        });

        if (onTouchListener != null){
            webView.setOnTouchListener(onTouchListener);
        }
        this.iDooAdCallBack = dooAdListener;
    }

    @Override
    public void startAd() {
        if (webView != null){
            webView.loadUrl(getDataSource().getUrl());
        }
    }

    private void startTimer(){
        if (timer != null)timer.cancel();
        timer = null;

        int delay = 0; // delay for 5 sec.
        int period = 1000; // repeat every sec.
        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
                                      public void run() {
                                          // Your code
                                          // get duration is millisecond
                                          if (getCurrentPosition() < getDuration())
                                          {
                                              count++;
                                          }else{
                                              if (onTouchListener != null){
                                                  //complette
                                              }
                                          }
                                      }
                                  }, delay,
                period);
    }
    @Override
    public void stopAd() {
        if (webView != null){
            webView.stopLoading();
            webView = null;
        }
        if (timer != null){
            timer.cancel();
            timer = null;

        }
    }

    @Override
    public void pause() {
        /*
           stop timer
        */
    }

    @Override
    public void resume() {
        /*
           resume timer
        */
    }

    @Override
    public long getDuration() {
        /*

        */
        return getDuration() /*milisecond*/;
    }

    @Override
    public boolean isPlaying() {
        if (webView != null){
            return webView.isShown();
        }
        return false;
    }

    @Override
    public long getCurrentPosition() {
        return count * 1000L;
    }

    @Override
    public void uninitial() {

    }

    @Override
    public View getInternalAdView() {
        return webView;
    }

    @Override
    public void setOnTouchListener(View.OnTouchListener touchListener) {
        this.onTouchListener =
                touchListener;
    }

    private class CustomWebClient extends WebViewClient
    {


        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;

        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);

            //start
            if (iDooAdCallBack != null)
            {

            }
            startTimer();
        }
    }
}
