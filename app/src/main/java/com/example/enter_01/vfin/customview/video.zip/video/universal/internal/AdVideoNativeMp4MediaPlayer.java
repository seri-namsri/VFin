package com.example.enter_01.vfin.customview.video.universal.internal;



import com.example.enter_01.vfin.customview.video.universal.IDooAdMediaPlayer;

import tv.danmaku.ijk.media.player.IMediaPlayer;

/**
 * Created by nickmsft on 11/25/2015 AD.
 * .
 */
public class AdVideoNativeMp4MediaPlayer implements IDooAdMediaPlayer {
    private IMediaPlayer mediaPlayer;

    public AdVideoNativeMp4MediaPlayer(IMediaPlayer mediaPlayer) {
        this.mediaPlayer = mediaPlayer;
    }

    @Override
    public void setVolume(float var1, float var2) {
        try {
            this.mediaPlayer.setVolume(var1, var2);
        } catch (IllegalStateException e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean isPlaying() {
        return mediaPlayer.isPlaying();
    }
}
