package com.example.enter_01.vfin.customview.video.videonative;

import android.content.Context;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.MediaController;

/**
 * Created by nickmsft on 11/14/2015 AD.
 * .
 */
public class DooAdsMediaController extends MediaController implements IMediaController {
    public DooAdsMediaController(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public DooAdsMediaController(Context context, boolean useFastForward) {
        super(context, useFastForward);
    }

    public DooAdsMediaController(Context context) {
        super(context);
    }

    @Override
    public void onFinishInflate() {
        super.onFinishInflate();
    }

    @Override
    public void setMediaPlayer(MediaPlayerControl player) {
        super.setMediaPlayer(player);
    }

    @Override
    public void setAnchorView(View view) {
        super.setAnchorView(view);
    }

    @Override
    public void show() {
        super.show();
    }

    @Override
    public void show(int timeout) {
        super.show(timeout);
    }

    @Override
    public boolean isShowing() {
        return super.isShowing();
    }

    @Override
    public void hide() {
        super.hide();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return super.onTouchEvent(event);
    }

    @Override
    public boolean onTrackballEvent(MotionEvent ev) {
        return super.onTrackballEvent(ev);
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        return super.dispatchKeyEvent(event);
    }

    @Override
    public void setEnabled(boolean enabled) {
        super.setEnabled(enabled);
    }

    @Override
    public CharSequence getAccessibilityClassName() {
        return super.getAccessibilityClassName();
    }

    @Override
    public void setPrevNextListeners(OnClickListener next, OnClickListener prev) {
        super.setPrevNextListeners(next, prev);
    }

    @Override
    public void showOnce(View view) {

    }
}
