package com.example.enter_01.vfin.customview.video.universal.internal.youtubewebview;

import android.content.Context;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.Toast;

import com.example.enter_01.vfin.utility.Log;


/**
 * Created by iceoton on 6/13/2016 AD.
 */
public class YoutubeWebViewPlayer {
    private final static String TAG = YoutubeWebViewPlayer.class.getSimpleName();
    Context mContext;
    private String videoId;
    private WebView webview;
    YoutubeWebViewListener youtubeWebViewListener;
    double currentTimeSec = 0;

    public YoutubeWebViewPlayer(Context context, WebView webview) {
        this.mContext = context;
        this.webview = webview;
        webview.setBackgroundColor(0);
        webview.setWebChromeClient(new WebChromeClient());
        webview.getSettings().setAllowFileAccess(true);
        webview.getSettings().setJavaScriptEnabled(true);
        webview.addJavascriptInterface(this, "AndroidFunction");
    }

    public void load(String videoId) {
        Log.d(TAG, " load video id " + videoId);
        this.videoId = videoId;
        webview.loadUrl("file:///android_asset/ads_youtube.html?id=" + videoId);
    }

    public void reload() {
        if (videoId != null) {
            load(videoId);
        }
    }

    public void pause() {
        webview.loadUrl("javascript:pauseVideo()");
    }

    public void play() {
        Log.d(TAG, " play video");
        webview.loadUrl("javascript:playVideo()");
    }

    public void setYoutubeWebViewListener(YoutubeWebViewListener listener) {
        this.youtubeWebViewListener = listener;
    }

    public void release() {
        this.webview.destroy();
    }

    public long getCurrentTimeMillis() {
        return (long) (currentTimeSec * 1000);
    }

    @JavascriptInterface
    public void showToast(String toast) {
        Toast.makeText(mContext, toast, Toast.LENGTH_SHORT).show();
    }

    @JavascriptInterface
    public void videoReady() {
        if (youtubeWebViewListener != null) {
            youtubeWebViewListener.onReady();
        }
    }

    @JavascriptInterface
    public void onVideoStarted(){
        if (youtubeWebViewListener != null) {
            youtubeWebViewListener.onPlay();
        }
    }

    @JavascriptInterface
    public void onVideoPlaying() {
        if (youtubeWebViewListener != null) {
            youtubeWebViewListener.onPlaying();
        }
    }

    @JavascriptInterface
    public void updateVideoTime(double time) {
        if (youtubeWebViewListener != null) {
            currentTimeSec = time;
            youtubeWebViewListener.onUpdateVideoTime(time);
        }
    }

    @JavascriptInterface
    public void onVideoEnd() {
        if (youtubeWebViewListener != null) {
            youtubeWebViewListener.onVideoEnded();
        }
    }


    @JavascriptInterface
    public void onPlayerError(String message) {
        if (youtubeWebViewListener != null) {
            youtubeWebViewListener.onError(message);
        }
    }


}
