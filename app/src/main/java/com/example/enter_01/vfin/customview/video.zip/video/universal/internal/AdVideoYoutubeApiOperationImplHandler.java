package com.example.enter_01.vfin.customview.video.universal.internal;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;

import com.example.enter_01.vfin.R;
import com.example.enter_01.vfin.customview.video.universal.BaseAdViewOperationHandler;
import com.example.enter_01.vfin.customview.video.universal.DataSource;
import com.example.enter_01.vfin.customview.video.universal.IAdViewOperationHandler;
import com.example.enter_01.vfin.customview.video.universal.IDooAdCallBack;
import com.example.enter_01.vfin.customview.video.universal.internal.youtube.DeveloperKey;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerSupportFragment;


public class AdVideoYoutubeApiOperationImplHandler extends BaseAdViewOperationHandler implements
        IAdViewOperationHandler, YouTubePlayer.OnInitializedListener {

    private final static String TAG = AdVideoYoutubeApiOperationImplHandler.class.getSimpleName();

    //private YouTubePlayerView youTubePlayerView;
    private YouTubePlayer youTubePlayer;
    private MyPlayerStateChangeListener playerStateChangeListener;
    private MyPlaybackEventListener playbackEventListener;
    IDooAdCallBack dooAdListener;

    public AdVideoYoutubeApiOperationImplHandler(Context context,
                                                     View view,
                                                     DataSource dataSource) {
        super(context, view, dataSource);
    }

    @Override
    public void stopAd() {
    }

    @Override
    public void pause() {
        if (youTubePlayer != null) {
            youTubePlayer.pause();
        }
    }

    @Override
    public void startAd() {
        if (youTubePlayer != null) {
            youTubePlayer.play();
        }
    }

    @Override
    public void resume() {
    }


    @Override
    public View getInternalAdView() {
        return null;
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void initial(boolean mute, Fragment container, final IDooAdCallBack dooAdListener) {
        LayoutInflater layoutInflater = LayoutInflater.from(getContext());
        View view = layoutInflater.inflate(R.layout.universal_youtube_api_layout, null);
        addAdPlayerToContainer(view);

        /*youTubePlayerView = (YouTubePlayerView) view.findViewById(R.id.youtube_view);
        youTubePlayerView.initialize(DeveloperKey.DEVELOPER_KEY, this);*/
        YouTubePlayerSupportFragment youTubePlayerSupportFragment = (YouTubePlayerSupportFragment)
                container.getActivity().getSupportFragmentManager().findFragmentById(R.id.youtube_support_fragment);
        youTubePlayerSupportFragment.initialize(DeveloperKey.DEVELOPER_KEY, this);
        playerStateChangeListener = new MyPlayerStateChangeListener();
        playbackEventListener = new MyPlaybackEventListener();
        this.dooAdListener = dooAdListener;

    }

    @Override
    public void setOnTouchListener(View.OnTouchListener touchListener) {
//        this.onTouchListener = touchListener;
    }

    @Override
    public long getDuration() {
        return getDataSource().getDuration();
    }

    @Override
    public boolean isPlaying() {
        return youTubePlayer.isPlaying();
    }

    @Override
    public long getCurrentPosition() {
        long currentTimeMillis = 0;
        if (youTubePlayer != null) {
            currentTimeMillis = youTubePlayer.getCurrentTimeMillis();
        }
        return currentTimeMillis;
    }

    @Override
    public void uninitial() {
        if (youTubePlayer != null) {
            youTubePlayer.release();
        }
    }

    @Override
    public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer youTubePlayer, boolean wasRestored) {
        this.youTubePlayer = youTubePlayer;
        this.youTubePlayer.setPlayerStyle(YouTubePlayer.PlayerStyle.MINIMAL);
        this.youTubePlayer.setPlayerStateChangeListener(playerStateChangeListener);
        this.youTubePlayer.setPlaybackEventListener(playbackEventListener);
        String url = getDataSource().getUrl();
        String videoId = url.split("=")[1];
        int lastIndexToSub = videoId.indexOf("&");
        if(lastIndexToSub > 0) {
            videoId = videoId.substring(0, lastIndexToSub);
        }
        this.youTubePlayer.cueVideo(videoId);
        this.youTubePlayer.addFullscreenControlFlag(YouTubePlayer.FULLSCREEN_FLAG_ALWAYS_FULLSCREEN_IN_LANDSCAPE);
    }

    @Override
    public void onInitializationFailure(YouTubePlayer.Provider provider, YouTubeInitializationResult youTubeInitializationResult) {
        Toast.makeText(getContext(), youTubeInitializationResult.toString(), Toast.LENGTH_SHORT).show();
    }

    private final class MyPlaybackEventListener implements YouTubePlayer.PlaybackEventListener {
        String playbackState = "NOT_PLAYING";
        String bufferingState = "";
        @Override
        public void onPlaying() {
            playbackState = "PLAYING";
            log("\tPLAYING " + getTimesText());
            if (dooAdListener != null) {
                dooAdListener.onPlaying();
            }
        }

        @Override
        public void onBuffering(boolean isBuffering) {
            bufferingState = isBuffering ? "(BUFFERING)" : "";
            log("\t\t" + (isBuffering ? "BUFFERING " : "NOT BUFFERING ") + getTimesText());
        }

        @Override
        public void onStopped() {
            playbackState = "STOPPED";
            log("\tSTOPPED");
        }

        @Override
        public void onPaused() {
            playbackState = "PAUSED";
            log("\tPAUSED " + getTimesText());
        }

        @Override
        public void onSeekTo(int endPositionMillis) {
            log(String.format("\tSEEKTO: (%s/%s)",
                    formatTime(endPositionMillis),
                    formatTime(youTubePlayer.getDurationMillis())));
        }
    }

    private final class MyPlayerStateChangeListener implements YouTubePlayer.PlayerStateChangeListener {
        String playerState = "UNINITIALIZED";

        @Override
        public void onLoading() {
            playerState = "LOADING";
            log(playerState);
            if (dooAdListener != null) {
                dooAdListener.onPrepare(null);
            }
        }

        @Override
        public void onLoaded(String videoId) {
            playerState = String.format("LOADED %s", videoId);
            log(playerState);
            if (dooAdListener != null) {
                dooAdListener.onLoadAdComplete();
            }
        }

        @Override
        public void onAdStarted() {
            playerState = "AD_STARTED";
            log(playerState);
        }

        @Override
        public void onVideoStarted() {
            playerState = "VIDEO_STARTED";
            log(playerState);
            dooAdListener.onPlay();
        }

        @Override
        public void onVideoEnded() {
            playerState = "VIDEO_ENDED";
            log(playerState);

            if (dooAdListener != null) {
                dooAdListener.onComplete(null, getDataSource(), true, youTubePlayer.getCurrentTimeMillis());
            }
        }

        @Override
        public void onError(YouTubePlayer.ErrorReason reason) {
            playerState = "ERROR (" + reason + ")";
            if (reason == YouTubePlayer.ErrorReason.UNEXPECTED_SERVICE_DISCONNECTION) {
                // When this error occurs the player is released and can no longer be used.
                youTubePlayer = null;
            }
            log(playerState);


        }

    }

    private String formatTime(int millis) {
        int seconds = millis / 1000;
        int minutes = seconds / 60;
        int hours = minutes / 60;

        return (hours == 0 ? "" : hours + ":")
                + String.format("%02d:%02d", minutes % 60, seconds % 60);
    }

    private String getTimesText() {
        int currentTimeMillis = youTubePlayer.getCurrentTimeMillis();
        int durationMillis = youTubePlayer.getDurationMillis();
        return String.format("(%s/%s)", formatTime(currentTimeMillis), formatTime(durationMillis));
    }

    private void log(String message) {
        Log.d(TAG, message);
    }
}
