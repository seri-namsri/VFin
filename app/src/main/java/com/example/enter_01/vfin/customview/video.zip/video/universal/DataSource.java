package com.example.enter_01.vfin.customview.video.universal;

/**
 * Created by nickmsft on 11/15/2015 AD.
 * .
 */
public class DataSource {
    private String formatType;
    private String url;
    private long duration;

    public String getFormatType() {
        return formatType;
    }

    public void setFormatType(String formatType) {
        this.formatType = formatType;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public long getDuration() {
        return duration;
    }

    public void setDuration(long duration) {
        this.duration = duration;
    }
}
